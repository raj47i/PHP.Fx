<?php

/*
D I S C L A I M E R                                                                                          
WARNING: ANY USE BY YOU OF THE SAMPLE CODE PROVIDED IS AT YOUR OWN RISK.                                                                                   
Authorize.Net provphpides this code "as is" without warranty of any kind, either express or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose.
Authorize.Net owns and retains all right, title and interest in and to the Automated Recurring Billing intellectual property.
*/

include_once ("vars.php");
include_once ("api_authorize_net_soap_v1.php");
include_once ("util.php");

$customerShippingAddressId = NULL;
if (isset($_REQUEST['customerShippingAddressId'])) {
	$customerShippingAddressId = $_REQUEST['customerShippingAddressId'];
}

echo "Create payment profile for customerProfileId <b>"
	. htmlspecialchars($_POST["customerProfileId"])
	. "</b>...<br><br>";

$ws = CreateWSClient();
$req = new CreateCustomerPaymentProfile();
$req->merchantAuthentication = PopulateMerchantAuthentication();
$req->customerProfileId = $_POST["customerProfileId"];
$req->paymentProfile = new CustomerPaymentProfileType();
$req->paymentProfile->billTo = new CustomerAddressType();
$req->paymentProfile->billTo->firstName = "John";
$req->paymentProfile->billTo->lastName = "Doe";
$req->paymentProfile->billTo->phoneNumber = "000-000-0000";
$req->paymentProfile->payment = new PaymentType();
$req->paymentProfile->payment->creditCard = new CreditCardType();
$req->paymentProfile->payment->creditCard->cardNumber = "4111111111111111";
$req->paymentProfile->payment->creditCard->expirationDate = "2020-08";  // required format for API is YYYY-MM
$req->validationMode = "testMode"; // "liveMode";

try {
	$response = $ws->CreateCustomerPaymentProfile($req);
	//echo "Raw request: " . htmlspecialchars($ws->__getLastRequest()) . "<br><br>";
	//echo "Raw response: " . htmlspecialchars($ws->__getLastResponse()) . "<br><br>";
	if ("Ok" == $response->CreateCustomerPaymentProfileResult->resultCode) {
		echo "customerPaymentProfileId <b>"
			. htmlspecialchars($response->CreateCustomerPaymentProfileResult->customerPaymentProfileId)
			. "</b> was successfully created for customerProfileId <b>"
			. htmlspecialchars($_POST["customerProfileId"])
			. "</b>.<br><br>";
	} else {
		echo "The operation failed with the following errors:<br>";
		PrintErrors($response->CreateCustomerPaymentProfileResult);
	}
} catch (SoapFault $exception) {
	echo $exception . "<br><br>";
}

echo "<br><a href=index.php?customerProfileId=" 
	. urlencode($_POST["customerProfileId"])
	. "&customerPaymentProfileId="
	. urlencode($response->CreateCustomerPaymentProfileResult->customerPaymentProfileId)
	. "&customerShippingAddressId="
	. urlencode($customerShippingAddressId)
	. ">Continue</a><br>";
?>

