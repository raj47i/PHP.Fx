<?php

/*
D I S C L A I M E R                                                                                          
WARNING: ANY USE BY YOU OF THE SAMPLE CODE PROVIDED IS AT YOUR OWN RISK.                                                                                   
Authorize.Net provphpides this code "as is" without warranty of any kind, either express or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose.
Authorize.Net owns and retains all right, title and interest in and to the Automated Recurring Billing intellectual property.
*/

include_once ("vars.php");
include_once ("api_authorize_net_soap_v1.php");
include_once ("util.php");

echo "Create transaction for customerProfileId <b>"
	. htmlspecialchars($_POST["customerProfileId"])
	. "</b>, customerPaymentProfileId <b>"
	. htmlspecialchars($_POST["customerPaymentProfileId"])
	. "</b>, customerShippingAddressId <b>"
	. htmlspecialchars($_POST["customerShippingAddressId"])
	. "</b>...<br><br>";

$ws = CreateWSClient();
$req = new CreateCustomerProfileTransaction();
$req->merchantAuthentication = PopulateMerchantAuthentication();
$tran = new ProfileTransAuthCaptureType();
$tran->amount = $_POST["amount"]; // should include tax, shipping, and everything.
$tran->shipping = new ExtendedAmountType();
$tran->shipping->amount = "0.00";
$tran->shipping->name = "Free Shipping";
$tran->shipping->description = "Free UPS Ground shipping. Ships in 5-10 days.";
$lineItem = new LineItemType();
$lineItem->itemId = "123456";
$lineItem->name = "item name";
$lineItem->description = "some description";
$lineItem->quantity = 1;
$lineItem->unitPrice = $_POST["amount"];
$lineItem->taxable = FALSE;
$tran->lineItems = array($lineItem);
$tran->customerProfileId = $_POST["customerProfileId"];
$tran->customerPaymentProfileId = $_POST["customerPaymentProfileId"];
$tran->customerShippingAddressId = $_POST["customerShippingAddressId"];
$tran->order = new OrderExType();
$tran->order->invoiceNumber = "INV12345";

$req->transaction = array("profileTransAuthCapture" => $tran); //On some older PHP implementations you need to use this instead.
//$req->transaction = new ProfileTransactionType();
//$req->transaction->profileTransAuthCapture = $tran;

//print_r($req); echo "<br><br>";

try {
	$response = $ws->CreateCustomerProfileTransaction($req);
	//echo "Raw request: " . htmlspecialchars($ws->__getLastRequest()) . "<br><br>";
	//echo "Raw response: " . htmlspecialchars($ws->__getLastResponse()) . "<br><br>";
	if ("Ok" == $response->CreateCustomerProfileTransactionResult->resultCode) {
		echo "A transaction was successfully created for customerProfileId <b>"
			. htmlspecialchars($_POST["customerProfileId"])
			. "</b>.<br><br>";
	} else {
		echo "The operation failed with the following errors:<br>";
		PrintErrors($response->CreateCustomerProfileTransactionResult);
	}
	if (isset($response->CreateCustomerProfileTransactionResult->directResponse)) {
		echo "direct response: <br>"
			. htmlspecialchars($response->CreateCustomerProfileTransactionResult->directResponse)
			. "<br><br>";
			
		$directResponseFields = explode(",", $response->CreateCustomerProfileTransactionResult->directResponse);
		$responseCode = $directResponseFields[0]; // 1 = Approved 2 = Declined 3 = Error
		$responseReasonCode = $directResponseFields[2]; // See http://www.authorize.net/support/AIM_guide.pdf
		$responseReasonText = $directResponseFields[3];
		$approvalCode = $directResponseFields[4]; // Authorization code
		$transId = $directResponseFields[6];
		
		if ("1" == $responseCode) echo "The transaction was successful.<br>";
		else if ("2" == $responseCode) echo "The transaction was declined.<br>";
		else echo "The transaction resulted in an error.<br>";
		
		echo "responseReasonCode = " . htmlspecialchars($responseReasonCode) . "<br>";
		echo "responseReasonText = " . htmlspecialchars($responseReasonText) . "<br>";
		echo "approvalCode = " . htmlspecialchars($approvalCode) . "<br>";
		echo "transId = " . htmlspecialchars($transId) . "<br>";
	}
} catch (SoapFault $exception) {
	echo $exception . "<br><br>";
}

echo "<br><a href=index.php?customerProfileId=" 
	. urlencode($_POST["customerProfileId"])
	. "&customerPaymentProfileId="
	. urlencode($_POST["customerPaymentProfileId"])
	. "&customerShippingAddressId="
	. urlencode($_POST["customerShippingAddressId"])
	. ">Continue</a><br>";
?>

