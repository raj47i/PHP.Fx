<?
// You may want to store this more securely in a DB or Registry or a Encrypted File
$loginid = "ENTER LOGINID HERE";
$x_tran_key = "ENTER x_tran_key HERE";
?>
